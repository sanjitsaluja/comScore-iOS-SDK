//
//  CSApplicationState.h
//  comScore
//
// Copyright 2014 comScore, Inc. All right reserved.
//

typedef enum {
    CSApplicationStateForeground,
    CSApplicationStateBackgroundUxActive,
    CSApplicationStateInactive
} CSApplicationState;